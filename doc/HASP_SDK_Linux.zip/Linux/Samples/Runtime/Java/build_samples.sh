#! /bin/sh

echo "Building HASP Java Samples"
if [ "$JDK" = "" ]; then
echo "Error:please set the variable JDK first"
exit 0 
fi

rm -f hasp_demo.class
rm -f hasp_update.class

$JDK/bin/javac hasp_demo.java
$JDK/bin/javac hasp_update.java
